const { hot } = require("react-hot-loader/root")

// prefer default export if available
const preferDefault = m => m && m.default || m


exports.components = {
  "component---node-modules-gatsby-plugin-offline-app-shell-js": hot(preferDefault(require("D:\\- FLB -\\random-romlik\\node_modules\\gatsby-plugin-offline\\app-shell.js"))),
  "component---src-templates-docs-js": hot(preferDefault(require("D:\\- FLB -\\random-romlik\\src\\templates\\docs.js")))
}

