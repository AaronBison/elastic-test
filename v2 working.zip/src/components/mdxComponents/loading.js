import * as React from 'react';

const LoadingProvider = ({ ...props }) => {
  return <div></div>;
};

export default LoadingProvider;
